import json
import boto3

dynamodb = boto3.resource('dynamodb')
login_table = dynamodb.Table('login')  # table name must match exactly

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event

        if body.get("action") != "register":
            return {
                "statusCode": 400,
                "body": json.dumps({ "error": "Invalid action." })
            }

        email = body.get("email")
        user_name = body.get("user_name")
        password = body.get("password")

        if not all([email, user_name, password]):
            return {
                "statusCode": 400,
                "body": json.dumps({ "error": "Missing required fields." })
            }

        # Use get_item instead of query
        response = login_table.get_item(Key={'email': email})
        if 'Item' in response:
            return {
                "statusCode": 409,
                "body": json.dumps({ "message": "The email already exists" })
            }

        login_table.put_item(Item={
            'email': email,
            'user_name': user_name,
            'password': password  # consistent key casing
        })

        return {
            "statusCode": 200,
            "body": json.dumps({ "message": "Registered successfully. Please login." }),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*"
            }
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({ "error": str(e) }),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*"
            }
        }

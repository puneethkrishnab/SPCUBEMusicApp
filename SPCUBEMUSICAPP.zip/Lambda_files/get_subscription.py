import json
import boto3
from boto3.dynamodb.conditions import Key

# AWS resources
dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')
subscription_table = dynamodb.Table('subscription')
music_table = dynamodb.Table('music')
bucket_name = 's4058517'  # Images are directly stored here (no folder prefix)

def lambda_handler(event, context):
    try:
        # Parse event body
        body = json.loads(event['body']) if 'body' in event else event
        action = body.get("action")
        email = body.get("email")

        # ✅ Validate request
        if action != "get_subscriptions":
            return respond(400, { "error": "Invalid action." })
        if not email:
            return respond(400, { "error": "Missing email." })

        # ✅ Query subscriptions by user_email
        result = subscription_table.query(
            KeyConditionExpression=Key('user_email').eq(email)
        )

        subscriptions = []
        for item in result.get('Items', []):
            title = item.get('title')
            album = item.get('album')
            artist = item.get('artist')
            year = item.get('year')
            sub_id = item.get('subscription_id')

            # Fetch music item to get image_url
            music_item = music_table.get_item(Key={'title': title, 'album': album}).get('Item', {})
            image_url = music_item.get("image_url", "")

            # ✅ Generate pre-signed URL from image filename
            signed_url = ""
            if image_url:
                image_key = image_url.split("/")[-1]
                try:
                    signed_url = s3.generate_presigned_url(
                        'get_object',
                        Params={ 'Bucket': bucket_name, 'Key': image_key },
                        ExpiresIn=3600
                    )
                except Exception as e:
                    print(f"Failed to sign {image_key}: {e}")

            subscriptions.append({
                "id": sub_id,
                "title": title,
                "artist": artist,
                "year": year,
                "album": album,
                "imageUrl": signed_url
            })

        return respond(200, subscriptions)

    except Exception as e:
        return respond(500, { "error": str(e) })

def respond(code, body):
    return {
        "statusCode": code,
        "body": json.dumps(body),
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*"
        }
    }

import json
import boto3

dynamodb = boto3.resource('dynamodb')
login_table = dynamodb.Table('login')  # Ensure table name is correct

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event

        if body.get("action") != "get_user_info":
            return {
                "statusCode": 400,
                "body": json.dumps({ "error": "Invalid action." })
            }

        email = body.get("email")
        if not email:
            return {
                "statusCode": 400,
                "body": json.dumps({ "error": "Missing email field." })
            }

        response = login_table.get_item(Key={'email': email})
        item = response.get('Item')

        if not item:
            return {
                "statusCode": 404,
                "body": json.dumps({ "error": "User not found." })
            }

        return {
            "statusCode": 200,
            "body": json.dumps({ "user_name": item['user_name'] }),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*"
            }
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({ "error": str(e) }),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*"
            }
        }

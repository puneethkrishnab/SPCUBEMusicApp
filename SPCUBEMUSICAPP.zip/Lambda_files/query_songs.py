import json
import boto3

dynamodb = boto3.resource('dynamodb')
music_table = dynamodb.Table('music')
s3 = boto3.client('s3')
bucket_name = 's4058517'  # Replace with your actual bucket name

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event

        # ✅ Validate action
        if body.get("action") != "query_songs":
            return respond(400, { "error": "Invalid action" })

        # ✅ Normalize input (case-insensitive)
        title_query = body.get("title", "").lower()
        artist_query = body.get("artist", "").lower()
        album_query = body.get("album", "").lower()
        year_query = body.get("year", "")

        # ✅ Get all items from music table
        response = music_table.scan()
        items = response.get("Items", [])
        matched = []

        for song in items:
            title = song.get("title", "").lower()
            artist = song.get("artist", "").lower()
            album = song.get("album", "").lower()
            year = song.get("year", "")

            # ✅ Apply case-insensitive matching
            if title_query and title_query not in title:
                continue
            if artist_query and artist_query not in artist:
                continue
            if album_query and album_query not in album:
                continue
            if year_query and year_query != year:
                continue

            # ✅ Generate signed S3 image URL
            image_url = song.get('image_url', '')
            if image_url:
                image_key = image_url.split("/")[-1]
                try:
                    presigned_url = s3.generate_presigned_url(
                        'get_object',
                        Params={'Bucket': bucket_name, 'Key': image_key},
                        ExpiresIn=3600
                    )
                    song["imageUrl"] = presigned_url
                except Exception:
                    song["imageUrl"] = ""

            matched.append(song)

        return respond(200, matched)

    except Exception as e:
        return respond(500, { "error": str(e) })

def respond(code, body):
    return {
        "statusCode": code,
        "body": json.dumps(body),
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*"
        }
    }

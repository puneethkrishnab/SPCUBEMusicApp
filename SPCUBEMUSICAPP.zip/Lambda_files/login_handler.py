import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('login')  # Ensure table name is correct

def lambda_handler(event, context):
    try:
        body = event if 'body' not in event else json.loads(event['body'])
        action = body.get("action")
        email = body.get("email")
        password = body.get("password")

        if action != "login":
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid action"})
            }

        # Get item by primary key (email)
        response = table.get_item(Key={'email': email})

        if 'Item' not in response:
            return {
                "statusCode": 401,
                "body": json.dumps({"message": "Email or password is invalid"})
            }

        item = response['Item']
        if item['password'] != password:
            return {
                "statusCode": 401,
                "body": json.dumps({"message": "Email or password is invalid"})
            }

        return {
            "statusCode": 200,
            "body": json.dumps({
                "email": item['email'],
                "user_name": item['user_name']
            }),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "*"
            }
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "*"
            }
        }

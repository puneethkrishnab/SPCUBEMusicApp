import json
import boto3

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
subscription_table = dynamodb.Table('subscription')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event
        action = body.get("action")
        email = body.get("email")
        sub_id = body.get("subscription_id")

        if action != "remove_subscription":
            return respond(400, { "error": "Invalid action." })
        if not email or not sub_id:
            return respond(400, { "error": "Missing email or subscription ID." })

        # ✅ Delete the item from DynamoDB
        subscription_table.delete_item(
            Key={
                'user_email': email,
                'subscription_id': sub_id
            }
        )

        return respond(200, { "message": "Subscription removed successfully." })

    except Exception as e:
        return respond(500, { "error": str(e) })

def respond(code, body):
    return {
        "statusCode": code,
        "body": json.dumps(body),
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*"
        }
    }

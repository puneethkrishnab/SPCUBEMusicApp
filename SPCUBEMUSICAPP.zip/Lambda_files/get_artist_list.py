import json
import boto3
from boto3.dynamodb.conditions import Attr

dynamodb = boto3.resource('dynamodb')
music_table = dynamodb.Table('music')
s3 = boto3.client('s3')
bucket_name = 's4058517'  # Your actual S3 bucket

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event
        action = body.get("action")

        # 🎯 1. Suggest artist names based on prefix (case-insensitive)
        if action == "get_artist_list":
            prefix = body.get("prefix", "").lower()
            if not prefix:
                return respond(400, { "error": "Missing prefix" })

            scan_result = music_table.scan()
            artist_set = set()
            for item in scan_result.get("Items", []):
                artist = item.get("artist", "")
                if artist.lower().startswith(prefix):
                    artist_set.add(artist)

            return respond(200, sorted(artist_set))

        # 🔍 2. Query songs
        if action == "query_songs":
            filters = []
            if 'title' in body and body['title']:
                filters.append(Attr('title').contains(body['title']))
            if 'artist' in body and body['artist']:
                filters.append(Attr('artist').contains(body['artist']))
            if 'album' in body and body['album']:
                filters.append(Attr('album').contains(body['album']))
            if 'year' in body and body['year']:
                filters.append(Attr('year').contains(body['year']))

            if not filters:
                return respond(400, { "error": "At least one query field is required." })

            filter_expr = filters[0]
            for f in filters[1:]:
                filter_expr = filter_expr & f

            response = music_table.scan(FilterExpression=filter_expr)
            items = response.get("Items", [])

            for song in items:
                image_url = song.get('image_url', '')
                if image_url:
                    image_key = image_url.split('/')[-1]
                    try:
                        signed_url = s3.generate_presigned_url(
                            'get_object',
                            Params={'Bucket': bucket_name, 'Key': image_key},
                            ExpiresIn=3600
                        )
                        song['imageUrl'] = signed_url
                    except Exception:
                        song['imageUrl'] = ""

            return respond(200, items)

        # ❌ Invalid action fallback
        return respond(400, { "error": "Invalid action" })

    except Exception as e:
        return respond(500, { "error": str(e) })

def respond(code, body):
    return {
        "statusCode": code,
        "body": json.dumps(body),
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*"
        }
    }

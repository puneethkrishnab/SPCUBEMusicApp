import json
import uuid
import boto3

dynamodb = boto3.resource('dynamodb')
music_table = dynamodb.Table('music')
subscription_table = dynamodb.Table('subscription')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if 'body' in event else event

        if body.get("action") != "subscribe":
            return respond(400, { "error": "Invalid action." })

        email = body.get("email")
        title = body.get("title")
        artist = body.get("artist")
        album = body.get("album")
        year = body.get("year")

        if not all([email, title, artist, album, year]):
            return respond(400, { "error": "Missing one or more required fields." })

        # Optional: Check if song exists in music table
        music_item = music_table.get_item(Key={'title': title, 'album': album}).get('Item')
        if not music_item:
            return respond(404, { "error": "Song not found in music database." })

        # Generate a new subscription ID
        subscription_id = str(uuid.uuid4())

        # Store subscription (we assume you only store song metadata + image_url handled later)
        subscription_table.put_item(Item={
            'user_email': email,
            'subscription_id': subscription_id,
            'title': title,
            'artist': artist,
            'album': album,
            'year': year
        })

        return respond(200, { "message": "Subscription successful." })

    except Exception as e:
        return respond(500, { "error": str(e) })

def respond(code, body):
    return {
        "statusCode": code,
        "body": json.dumps(body),
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*"
        }
    }

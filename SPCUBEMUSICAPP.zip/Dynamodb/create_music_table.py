import boto3
from botocore.exceptions import ClientError

# Create a DynamoDB client
# boto3 will automatically pick up your AWS CLI credentials from ~/.aws/credentials
dynamodb_client = boto3.client('dynamodb', region_name='us-east-1')

# Define table name and key schema based on our design
table_name = 'music'

try:
    # Create table with 'title' as partition key and 'album' as sort key
    response = dynamodb_client.create_table(
        TableName=table_name,
        AttributeDefinitions=[
            {
                'AttributeName': 'title',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'album',
                'AttributeType': 'S'
            }
        ],
        KeySchema=[
            {
                'AttributeName': 'title',
                'KeyType': 'HASH'   # Partition key
            },
            {
                'AttributeName': 'album',
                'KeyType': 'RANGE'  # Sort key
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )

    print(f"Table creation initiated for '{table_name}'.")
    
    # Wait until the table exists.
    dynamodb_resource = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb_resource.Table(table_name)
    table.meta.client.get_waiter('table_exists').wait(TableName=table_name)
    
    print(f"Table '{table_name}' created successfully and is now active.")

except ClientError as e:
    print("Error creating table:", e.response['Error']['Message'])

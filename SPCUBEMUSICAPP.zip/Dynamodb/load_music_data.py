import boto3
import json
from botocore.exceptions import ClientError

# Create a DynamoDB resource in the same region as your table
dynamodb_resource = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb_resource.Table('music')

# Path to your JSON file
json_file_path = '2025a1.json'

def load_data_to_dynamodb():
    try:
        # Open and load the JSON data from the file
        with open(json_file_path, 'r') as file:
            data = json.load(file)
        
        # Extract the list of songs using the "songs" key
        items = data.get("songs")
        if not isinstance(items, list):
            print("Error: Expected a list of items under the 'songs' key in the JSON file.")
            return

        # Insert each song record into the DynamoDB table
        for item in items:
            # Convert "img_url" to "image_url" as expected by your specification.
            if "img_url" in item:
                item["image_url"] = item.pop("img_url")
            try:
                response = table.put_item(Item=item)
                print(f"Inserted item: {item.get('title', 'Unknown Title')}")
            except ClientError as e:
                print(f"Failed to insert item: {item.get('title', 'Unknown Title')}. Error: {e.response['Error']['Message']}")
    except Exception as e:
        print(f"Error reading JSON file: {str(e)}")

if __name__ == "__main__":
    load_data_to_dynamodb()

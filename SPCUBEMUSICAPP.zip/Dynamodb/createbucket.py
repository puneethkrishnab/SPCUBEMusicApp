import boto3
from botocore.exceptions import ClientError

def create_bucket(bucket_name, region=None):
    """
    Create an S3 bucket in a specified region.
    If no region is specified, the default is us-east-1.
    For us-east-1, no CreateBucketConfiguration is required.
    """
    try:
        if region is None or region == 'us-east-1':
            # For us-east-1, do not specify CreateBucketConfiguration
            s3_client = boto3.client('s3', region_name='us-east-1')
            s3_client.create_bucket(Bucket=bucket_name)
        else:
            s3_client = boto3.client('s3', region_name=region)
            # For other regions, specify the location constraint.
            location = {'LocationConstraint': region}
            s3_client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=location)
    except ClientError as e:
        print("Error creating bucket:", e.response['Error']['Message'])
        return False
    return True

if __name__ == '__main__':
    # Replace with your globally unique bucket name.
    bucket_name = 's4058517'  # Make sure the name is globally unique
    # Specify your desired region; for us-east-1, no location constraint is provided.
    region = 'us-east-1'
    
    if create_bucket(bucket_name, region):
        print(f"Bucket '{bucket_name}' created successfully in region '{region}'.")
    else:
        print(f"Bucket '{bucket_name}' could not be created.")

import boto3
from botocore.exceptions import ClientError

# ✅ Adjust the region if needed
dynamodb = boto3.client('dynamodb', region_name='us-east-1')

def create_subscription_table():
    try:
        response = dynamodb.create_table(
            TableName='subscription',  # Match your code exactly
            AttributeDefinitions=[
                { 'AttributeName': 'user_email', 'AttributeType': 'S' },
                { 'AttributeName': 'subscription_id', 'AttributeType': 'S' }
            ],
            KeySchema=[
                { 'AttributeName': 'user_email', 'KeyType': 'HASH' },  # Partition key
                { 'AttributeName': 'subscription_id', 'KeyType': 'RANGE' }  # Sort key
            ],
            ProvisionedThroughput={ 'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5 }
        )

        print("✅ Table creation initiated...")
        waiter = boto3.client('dynamodb', region_name='us-east-1').get_waiter('table_exists')
        waiter.wait(TableName='subscription')
        print("✅ Table 'subscription' is now active.")

    except ClientError as e:
        print(f"❌ Error: {e.response['Error']['Message']}")

if __name__ == "__main__":
    create_subscription_table()


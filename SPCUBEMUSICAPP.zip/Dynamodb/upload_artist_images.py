import json
import os
import requests
import boto3
from botocore.exceptions import ClientError

# -------- Configuration --------
JSON_FILE = '2025a1.json'
BUCKET_NAME = 's4058517'
REGION = 'us-east-1'
# FOLDER_PREFIX = 's4058517/'  # ❌ REMOVE THIS LINE
# --------------------------------

def read_songs(json_file):
    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
        return data.get('songs', [])
    except Exception as e:
        print(f"❌ Error reading JSON file: {e}")
        return []

def download_image(url):
    try:
        res = requests.get(url)
        res.raise_for_status()
        return res.content
    except Exception as e:
        print(f"❌ Failed to download {url}: {e}")
        return None

def upload_to_s3(image_data, file_name):
    s3 = boto3.client('s3', region_name=REGION)
    object_key = file_name  # ✅ Updated: Upload directly with filename at root of bucket
    try:
        s3.put_object(Bucket=BUCKET_NAME, Key=object_key, Body=image_data)
        print(f"✅ Uploaded: {object_key}")
    except ClientError as e:
        print(f"❌ Failed to upload {file_name}: {e.response['Error']['Message']}")

def main():
    songs = read_songs(JSON_FILE)
    for song in songs:
        url = song.get("img_url")
        if not url:
            continue
        image_data = download_image(url)
        if image_data:
            file_name = os.path.basename(url)
            upload_to_s3(image_data, file_name)

if __name__ == "__main__":
    main()
